package rita.support;

public interface LoadableIF
{
  public Object load(String s);
}
